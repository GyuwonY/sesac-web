package kr.co.mlec.member.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.co.mlec.controller.Controller;
import kr.co.mlec.member.service.MemberService;
import kr.co.mlec.member.vo.MemberVO;

public class DetailController implements Controller {

	@Override
	public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
		MemberService service = new MemberService();
		int no = Integer.parseInt(request.getParameter("no"));
		MemberVO member = service.selectByNo(no);
		request.setAttribute("userVO", member);
		return "/jsp/member/detail.jsp";
	}
	

}
