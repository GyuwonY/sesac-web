package kr.co.mlec.board.vo;

public class BoardFileVO {
	
	private int no;
	private int bNo;
	private String fileOriName;
	private String fileSaveName;
	private int fileSize;
	

	public BoardFileVO() {

	}

	public BoardFileVO(int no, int bNo, String fileOriName, String fileSaveName, int fileSize) {
		super();
		this.no = no;
		this.bNo = bNo;
		this.fileOriName = fileOriName;
		this.fileSaveName = fileSaveName;
		this.fileSize = fileSize;
	}
	
	public BoardFileVO(int no, String fileOriName, String fileSaveName, int fileSize) {
		super();
		this.no = no;
		this.fileOriName = fileOriName;
		this.fileSaveName = fileSaveName;
		this.fileSize = fileSize;
	}
	
	
	public int getNo() {
		return no;
	}


	public void setNo(int no) {
		this.no = no;
	}


	public int getBNo() {
		return bNo;
	}


	public void setBNo(int bNo) {
		this.bNo = bNo;
	}


	public String getFileOriName() {
		return fileOriName;
	}


	public void setFileOriName(String fileOriName) {
		this.fileOriName = fileOriName;
	}


	public String getFileSaveName() {
		return fileSaveName;
	}


	public void setFileSaveName(String fileSaveName) {
		this.fileSaveName = fileSaveName;
	}


	public int getFileSize() {
		return fileSize;
	}


	public void setFileSize(int fileSize) {
		this.fileSize = fileSize;
	}


	@Override
	public String toString() {
		return "BoardFileVO [no=" + no + ", bNo=" + bNo + ", fileOriName=" + fileOriName + ", fileSaveName="
				+ fileSaveName + ", fileSize=" + fileSize + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	}
	
	
}
