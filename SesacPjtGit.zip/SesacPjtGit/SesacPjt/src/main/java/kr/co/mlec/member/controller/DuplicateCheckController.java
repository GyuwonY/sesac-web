package kr.co.mlec.member.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.co.mlec.controller.Controller;
import kr.co.mlec.member.service.MemberService;
import kr.co.mlec.member.vo.MemberVO;

public class DuplicateCheckController implements Controller{

	@Override
	public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
		MemberService service = new MemberService();
		
		MemberVO member = new MemberVO();
		member.setId(request.getParameter("id"));
		request.setAttribute("result", service.duplicateCheckService(member));
		
		return "/jsp/member/result.jsp";
	}
}
