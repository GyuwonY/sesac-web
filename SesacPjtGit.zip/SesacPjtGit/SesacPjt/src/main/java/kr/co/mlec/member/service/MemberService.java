package kr.co.mlec.member.service;

import java.util.List;

import kr.co.mlec.member.dao.MemberDAO;
import kr.co.mlec.member.vo.MemberVO;

public class MemberService {
	
	private MemberDAO dao = null;
	private MemberVO member = null;
	
	
	
	public MemberService() {
		dao = new MemberDAO();
	}

	/**
	 * 회원 목록조회
	 */
	public List<MemberVO> selectAll() {
		List<MemberVO> members = dao.selectAll();
		
		return members;
	}
	
	/**
	 * ID 중복 조회
	 * @param member
	 * @return
	 */
	public boolean duplicateCheckService(MemberVO member) {
		boolean result = dao.duplicateCheck(member);
		
		return result;
	}
	
	/**
	 * 로그인
	 * @param member
	 */
	public MemberVO signIn(MemberVO member) {
		 return dao.signIn(member);
	}
	
	/**
	 * 회원가입
	 * @param member
	 */
	public void signUp(MemberVO member) {
		dao.signUp(member);
	}
	
	/**
	 * 회원정보 수정
	 * @param member
	 */
	public void update(MemberVO member) {
		boolean result = dao.update(member);
	}
	
	/**
	 * 회원탈퇴
	 */
	public void withdrawal(MemberVO member) {
		boolean result = dao.withdrawal(member);
	}
	
	/**
	 * 회원 상세조회
	 */
	public MemberVO selectByNo(int no) {
		member = dao.selectByNo(no);
		
		return member;
	}

}
