package kr.co.mlec.member.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.ArrayList;
import java.util.List;

import kr.co.mlec.member.vo.MemberVO;
import kr.co.mlec.util.ConnectionFactory;

public class MemberDAO {
	
	/**
	 * 전체 회원목록
	 */
	public List<MemberVO> selectAll() {
		StringBuilder sql = new StringBuilder();
		sql.append("select * from tbl_user ");
		List<MemberVO> members = new ArrayList<MemberVO>();
		try(
				Connection conn = new ConnectionFactory().getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql.toString());
			){
			ResultSet rs = pstmt.executeQuery();
			
			while(rs.next()){
				MemberVO member = new MemberVO(rs.getInt("no"),rs.getString("id"),
						rs.getString("pw"), rs.getString("name"), rs.getString("email"),
						rs.getString("nick_name"), rs.getInt("point"), rs.getString("grade"),
						rs.getInt("alert_cnt"), rs.getString("reg_date"));
				members.add(member);
			}
			}catch (Exception e){
			e.printStackTrace();
		}
		return members;
	}
	
	/**
	 * 회원 상세조회
	 */
	public MemberVO selectByNo(int no) {
		
		StringBuilder sql = new StringBuilder();
		sql.append("select * from tbl_user where no=? ");
		MemberVO member = null;
		try(
				Connection conn = new ConnectionFactory().getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql.toString());
			){
			pstmt.setInt(1, no);
			ResultSet rs = pstmt.executeQuery();
			
			while(rs.next()){
				member = new MemberVO();
				member.setNo(rs.getInt("no"));
				member.setId(rs.getString("id"));
				member.setPw(rs.getString("pw"));
				member.setName(rs.getString("name"));
				member.setEmail(rs.getString("email"));
				member.setNickName(rs.getString("nick_name"));
				member.setPoint(rs.getInt("point"));
				member.setGrade(rs.getString("grade"));
				member.setAlertCnt(rs.getInt("alert_cnt"));
				member.setRegDate(rs.getString("reg_date"));
			}
			}catch (Exception e){
			e.printStackTrace();
		}
		return member;
	}
	
	/**
	 * 중복확인
	 */
	public boolean duplicateCheck(MemberVO member) {
		StringBuilder selectSql = new StringBuilder();
		selectSql.append("select * from tbl_user where id=?");
		try(
			Connection conn = new ConnectionFactory().getConnection();
			PreparedStatement pstmt = conn.prepareStatement(selectSql.toString());
		){
			pstmt.setString(1, member.getId());
			ResultSet rs = pstmt.executeQuery();
			
			if(!rs.next()) {
				return true;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return false;
	}
	
	/**
	 * 회원 가입
	 */
	public boolean signUp(MemberVO member) {
		StringBuilder insertSql = new StringBuilder();
		insertSql.append("insert into tbl_user(no, id, pw, name, email, nick_name ) ");
		insertSql.append(" values(seq_tbl_user_no.nextval, ?, ?, ?, ?, ?) ");
		List<MemberVO> members = new ArrayList<MemberVO>();
		try(
			Connection conn = new ConnectionFactory().getConnection();
			PreparedStatement pstmt = conn.prepareStatement(insertSql.toString());
		){	
			pstmt.setString(1, member.getId());
			pstmt.setString(2, member.getPw());
			pstmt.setString(3, member.getName());
			pstmt.setString(4, member.getEmail());
			pstmt.setString(5, member.getNickName());
			pstmt.executeUpdate();

		}catch (SQLIntegrityConstraintViolationException s) {
			return false;
		}catch (Exception e){
			e.printStackTrace();
		}
		return false;
	}
	
	/**
	 * 로그인
	 */
	public MemberVO signIn(MemberVO member) {
		StringBuilder sql = new StringBuilder();
		sql.append("select * from tbl_user where id=? and pw=? "); 
		MemberVO userVO = null; 
		try(
				Connection conn = new ConnectionFactory().getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql.toString());
			){
			pstmt.setString(1, member.getId());
			pstmt.setString(2, member.getPw());
			ResultSet rs = pstmt.executeQuery();
			
			if(rs.next()) {
				userVO = new MemberVO();
				userVO.setNo(rs.getInt("no"));
				userVO.setId(rs.getString("id"));
				userVO.setPw(rs.getString("pw"));
				userVO.setName(rs.getString("name"));
				userVO.setEmail(rs.getString("email"));
				userVO.setNickName(rs.getString("nick_name"));
				userVO.setPoint(rs.getInt("point"));
				userVO.setGrade(rs.getString("grade"));
				userVO.setAlertCnt(rs.getInt("alert_cnt"));
				userVO.setRegDate(rs.getString("reg_date"));
				}
				
			}catch (Exception e){
				e.printStackTrace();
			}
		return userVO;
	}
	
	/**
	 * 회원탈퇴
	 */
	public boolean withdrawal(MemberVO member) {
		StringBuilder deleteSql = new StringBuilder();
		deleteSql.append("delete from tbl_user where id=? ");
		StringBuilder selectSql = new StringBuilder();
		selectSql.append("select * from tbl_user where id=? and pw=? ");
		try(
				Connection conn = new ConnectionFactory().getConnection();
				PreparedStatement pstmt = conn.prepareStatement(deleteSql.toString());
				PreparedStatement pstmt2 = conn.prepareStatement(selectSql.toString());
			){
			
			ResultSet rs = pstmt2.executeQuery();
			
			if(rs.next()) {
				pstmt.executeUpdate();
				return true;
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return false;
	}
	
	/**
	 * 회원 정보수정
	 */
	public boolean update(MemberVO member) {
		StringBuilder updateSql = new StringBuilder();
		updateSql.append("update tbl_user set no=?, pw=?, name=?, email=?, nick_name=?");
		updateSql.append(" where id=?, pw=? ");
		try(
				Connection conn = new ConnectionFactory().getConnection();
				PreparedStatement pstmt = conn.prepareStatement(updateSql.toString());
			){
			
			pstmt.executeUpdate();
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return false;
	}
	
	
}
