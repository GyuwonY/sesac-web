package kr.co.mlec.member.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import kr.co.mlec.controller.Controller;
import kr.co.mlec.member.service.MemberService;
import kr.co.mlec.member.vo.MemberVO;

public class SignInController implements Controller{

	@Override
	public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
		MemberService service = new MemberService();
		MemberVO userVO = new MemberVO();
		
		userVO.setId(request.getParameter("id"));
		userVO.setPw(request.getParameter("inPw"));
		userVO = service.signIn(userVO);
		
		if(userVO != null) {
			HttpSession session = request.getSession();
			session.setAttribute("userVO", userVO);
			return "redirect:/";
		}else {
			return "redirect:/member/signForm.do";
		}
		
	}
	
	
}
