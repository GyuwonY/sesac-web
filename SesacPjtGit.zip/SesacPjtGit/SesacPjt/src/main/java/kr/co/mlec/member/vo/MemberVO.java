package kr.co.mlec.member.vo;

public class MemberVO {
	private int no;
	private String id;
	private String pw;
	private String name;
	private String email;
	private String nickName;
	private int point;
	private String grade;
	private int alertCnt;
	private String regDate;
	
	public MemberVO() {
	
	}

	public MemberVO(int no, String id, String pw, String name, String email, String nickName, int point, String grade,
			int alertCnt, String regDate) {
		super();
		this.no = no;
		this.id = id;
		this.pw = pw;
		this.name = name;
		this.email = email;
		this.nickName = nickName;
		this.point = point;
		this.grade = grade;
		this.alertCnt = alertCnt;
		this.regDate = regDate;
	}

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPw() {
		return pw;
	}

	public void setPw(String pw) {
		this.pw = pw;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

	public int getPoint() {
		return point;
	}

	public void setPoint(int point) {
		this.point = point;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public int getAlertCnt() {
		return alertCnt;
	}

	public void setAlertCnt(int alertCnt) {
		this.alertCnt = alertCnt;
	}

	public String getRegDate() {
		return regDate;
	}

	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}

	@Override
	public String toString() {
		return "MemberVO [no=" + no + ", id=" + id + ", pw=" + pw + ", name=" + name + ", email=" + email
				+ ", nickName=" + nickName + ", point=" + point + ", grade=" + grade + ", alertCnt=" + alertCnt
				+ ", regDate=" + regDate + "]";
	}
	
	
}
