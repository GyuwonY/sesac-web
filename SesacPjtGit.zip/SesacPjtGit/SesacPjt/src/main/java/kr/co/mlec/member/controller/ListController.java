package kr.co.mlec.member.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.co.mlec.controller.Controller;
import kr.co.mlec.member.service.MemberService;
import kr.co.mlec.member.vo.MemberVO;

public class ListController implements Controller {

	@Override
	public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		MemberService service = new MemberService();
		List<MemberVO> members = service.selectAll();
		
		request.setAttribute("members", members);
		
		return "/jsp/member/list.jsp";
	}

}
