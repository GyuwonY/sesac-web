package kr.co.mlec.member.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.co.mlec.controller.Controller;
import kr.co.mlec.member.service.MemberService;
import kr.co.mlec.member.vo.MemberVO;

public class SignUpController implements Controller{

	@Override
	public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		MemberService service = new MemberService();
		
		MemberVO member = new MemberVO();
		member.setName(request.getParameter("name"));
		member.setId(request.getParameter("uid"));
		member.setPw(request.getParameter("pw"));
		member.setNickName(request.getParameter("nickName"));
		member.setEmail(request.getParameter("email"));
		
		service.signUp(member);
		
		return "redirect:/";
	}
}
