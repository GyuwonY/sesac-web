package kr.co.mlec.board.vo;

public class BoardVO {
	
	private int no;
	private String title;
	private String content;
	private String writer;
	private String regDate;
	private int viewCnt;
	private int likeRate;
	private int hateRate;
	private String category;
	private String id;
	
	public BoardVO() {
		
	}
	
	
	
	
	public BoardVO(int no, String title, String content, String writer, String regDate, int viewCnt, String id) {
		super();
		this.no = no;
		this.title = title;
		this.content = content;
		this.writer = writer;
		this.regDate = regDate;
		this.viewCnt = viewCnt;
		this.id = id;
	}




	public BoardVO(int no, String title, String content, String writer, String regDate, int viewCnt) {
		super();
		this.no = no;
		this.title = title;
		this.content = content;
		this.writer = writer;
		this.regDate = regDate;
		this.viewCnt = viewCnt;
	}


	public BoardVO(int no, String title, String writer, String regDate, int viewCnt) {
		super();
		this.no = no;
		this.title = title;
		this.writer = writer;
		this.regDate = regDate;
		this.viewCnt = viewCnt;
	}


	public BoardVO(int no, String title, String content, String writer, String regDate, int viewCnt, int likeRate,
			int hateRate, String category, String id) {
		super();
		this.no = no;
		this.title = title;
		this.content = content;
		this.writer = writer;
		this.regDate = regDate;
		this.viewCnt = viewCnt;
		this.likeRate = likeRate;
		this.hateRate = hateRate;
		this.category = category;
		this.id = id;
	}

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	public String getRegDate() {
		return regDate;
	}

	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}

	public int getViewCnt() {
		return viewCnt;
	}

	public void setViewCnt(int viewCnt) {
		this.viewCnt = viewCnt;
	}

	public int getLikeRate() {
		return likeRate;
	}

	public void setLikeRate(int likeRate) {
		this.likeRate = likeRate;
	}

	public int getHateRate() {
		return hateRate;
	}

	public void setHateRate(int hateRate) {
		this.hateRate = hateRate;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}


	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	@Override
	public String toString() {
		return "BoardVO [no=" + no + ", title=" + title + ", content=" + content + ", writer=" + writer + ", regDate="
				+ regDate + ", viewCnt=" + viewCnt + ", likeRate=" + likeRate + ", hateRate=" + hateRate + ", category="
				+ category + ", id=" + id + "]";
	}
	
	

}
