/*global $, document, window, setTimeout, navigator, console, location*/

    var usernameError = true,
    	emailError    = true,
    	uidError 	  = true,
    	idError 	  = true,
    	inPwError	  = true,
    	nicknameError = true,
    	passwordError = true,
    	passConfirm   = true;
$(document).ready(function () {

    'use strict';

    // Detect browser for css purpose
    if (navigator.userAgent.toLowerCase().indexOf('firefox') > -1) {
        $('.form form label').addClass('fontSwitch');
    }

    // Label effect
    $('input').focus(function () {

        $(this).siblings('label').addClass('active');
    });
    

    // Form validation
    $('input').blur(function () {
		
		//id
		if ($(this).hasClass('id')) {
            if ($(this).val().length === 0) {
                $(this).siblings('span.error').text('아이디를 입력해주세요').fadeIn().parent('.form-group').addClass('hasError');
                $('#spanId').css('color', 'red')
                idError = true;
            } else {
                idError = false;
            }
        }
		
		//inPw
		if ($(this).hasClass('inPw')) {
            if ($(this).val().length === 0) {
                $(this).siblings('span.error').text('아이디를 입력해주세요').fadeIn().parent('.form-group').addClass('hasError');
                $('#spanId').css('color', 'red')
                inPwError = true;
            } else {
                inPwError = false;
            }
        }
        
		// uid
        if ($(this).hasClass('uid')) {
            if ($(this).val().length === 0) {
                $(this).siblings('span.error').text('아이디를 입력해주세요').fadeIn().parent('.form-group').addClass('hasError');
                $('#spanId').css('color', 'red')
                uidError = true;
            } else if ($(this).val().length >=1 && $(this).val().length <=5) {
                $(this).siblings('span.error').text('아이디는 6글자 이상 입력해주세요').fadeIn().parent('.form-group').addClass('hasError');
                $('#spanId').css('color', 'red')
                uidError = true;
            }
        }
		
		// Nick Name
        if ($(this).hasClass('nickName')) {
            if ($(this).val().length === 0) {
                $(this).siblings('span.error').text('닉네임을 입력해주세요').fadeIn().parent('.form-group').addClass('hasError');
                $('#spanId').css('color', 'red')
                nicknameError = true;
            } else if ($(this).val().length == 1) {
                $(this).siblings('span.error').text('닉네임은 2글자 이상 입력해주세요').fadeIn().parent('.form-group').addClass('hasError');
                $('#spanId').css('color', 'red')
                nicknameError = true;
            } else {
                $(this).siblings('.error').text('').fadeOut().parent('.form-group').removeClass('hasError');
                nicknameError = false;
            }
        }
		
        // User Name
        if ($(this).hasClass('name')) {
            if ($(this).val().length === 0) {
                $(this).siblings('span.error').text('이름을 입력해주세요').fadeIn().parent('.form-group').addClass('hasError');
                $('#spanId').css('color', 'red')
                usernameError = true;
            } else if ($(this).val().length == 1) {
                $(this).siblings('span.error').text('이름은 2글자 이상 입력해주세요').fadeIn().parent('.form-group').addClass('hasError');
                $('#spanId').css('color', 'red')
                usernameError = true;
            } else {
                $(this).siblings('.error').text('').fadeOut().parent('.form-group').removeClass('hasError');
                usernameError = false;
            }
        }
        // Email
        if ($(this).hasClass('email')) {
            if ($(this).val().length == '') {
                $(this).siblings('span.error').text('이메일을 입력해주세요').fadeIn().parent('.form-group').addClass('hasError');
                $('#spanId').css('color', 'red')
                emailError = true;
            } else {
                $(this).siblings('.error').text('').fadeOut().parent('.form-group').removeClass('hasError');
                $('#spanId').css('color', 'red')
                emailError = false;
            }
        }

        // PassWord
        if ($(this).hasClass('pass')) {
            if ($(this).val().length < 8) {
                $(this).siblings('span.error').text('비밀번호는 8글자 이상 입력해주세요').fadeIn().parent('.form-group').addClass('hasError');
                $('#spanId').css('color', 'red')
                passwordError = true;
            } else {
                $(this).siblings('.error').text('').fadeOut().parent('.form-group').removeClass('hasError');
                passwordError = false;
            }
        }

        // PassWord confirmation
        if ($('.pass').val() !== $('.passConfirm').val()) {
            $('.passConfirm').siblings('.error').text('비밀번호가 일치하지 않습니다').fadeIn().parent('.form-group').addClass('hasError');
            $('#spanId').css('color', 'red')
            passConfirm = true;
        } else {
            $('.passConfirm').siblings('.error').text('').fadeOut().parent('.form-group').removeClass('hasError');
            passConfirm = false;
        }

        // label effect
        if ($(this).val().length > 0) {
            $(this).siblings('label').addClass('active');
        } else {
            $(this).siblings('label').removeClass('active');
        }
    });

    // form switch
    $('a.switch').click(function (e) {
        $(this).toggleClass('active');
        e.preventDefault();

        if ($('a.switch').hasClass('active')) {
            $(this).parents('.form-peice').addClass('switched').siblings('.form-peice').removeClass('switched');
        } else {
            $(this).parents('.form-peice').removeClass('switched').siblings('.form-peice').addClass('switched');
        }
    });

    // Reload page
    $('a.profile').on('click', function () {
        location.reload(true);
    });
	
	
	
});

	function checkForm(){
		if (uidError == true || nicknameError == true || usernameError == true || emailError == true || passwordError == true || passConfirm == true) {
	        $('.uid, .nickName, .name, .email, .pass, .passConfirm').blur();
        	return false
    	}
    	alert("회원가입이 완료되었습니다.")
    	return true
	}
	
	function checkInForm(){
		console.log(idError)
		if (idError == true || inPwError == true ) {
	        $('.id, .inPw').blur();
	        
        	return false
    	}
    	return true
	}
